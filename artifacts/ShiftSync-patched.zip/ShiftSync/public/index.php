<?php
declare(strict_types=1);
require dirname(__DIR__) . '/src/bootstrap.php';
Page::head('A clearer week for your lab team');
?>
<header class="public-header container"><?php Page::brand(); ?><a class="btn btn-secondary" href="<?= e(url('login.php')) ?>">Sign in <span aria-hidden="true">↗</span></a></header>
<main id="main" class="public-main container">
    <section class="public-intro">
        <span class="pill">Duty roster management</span>
        <h1 class="public-title">A clearer week.<br>A covered lab.</h1>
        <p class="public-copy">Bring availability, lab coverage and approved shift exchanges into one considered workspace.</p>
        <a class="btn btn-primary" href="<?= e(url('login.php')) ?>">Open your workspace <span aria-hidden="true">→</span></a>
        <p class="muted public-context">Northfield College · Computer lab support · Asia/Kolkata</p>
    </section>
    <section class="intro-workflow" aria-labelledby="workflow-heading">
        <div class="panel-head"><h2 id="workflow-heading">From availability to an approved exchange</h2><span class="pill">How it works</span></div>
        <ol class="workflow-list">
            <li><span class="workflow-number">01</span><div><h3>Share your availability</h3><p>Tell your team which morning and afternoon blocks you can cover.</p></div></li>
            <li><span class="workflow-number">02</span><div><h3>Publish a covered week</h3><p>Your supervisor checks headcount and technician coverage before publishing.</p></div></li>
            <li><span class="workflow-number">03</span><div><h3>Exchange with confidence</h3><p>A colleague accepts, your supervisor reviews, and both duties update together.</p></div></li>
        </ol>
        <div class="intro-note">Built for one college, two laboratories and the people keeping them running.</div>
    </section>
</main>
<footer class="public-footer container"><span>ShiftSync</span><span>Scheduled duties. Clear decisions.</span></footer>
<?php Page::foot(); ?>
